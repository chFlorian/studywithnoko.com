# Noko Presskit  

Welcome to the official presskit for **Noko** – the study timer with a buddy.  
This folder contains everything you need to write about or feature Noko, including screenshots, logos, and an overview of the app.  

---

## 📖 About Noko  
Noko transforms studying from a stressful chore into something motivating and fun. Instead of a cold stopwatch, students are accompanied by a friendly *study buddy* character who keeps them focused, celebrates progress, and makes learning feel approachable.  

Key highlights:  
- Friendly characters (Noko the turtle, Blinky the fox, Owliver the owl) with unique personalities  
- Gamified but gentle — earn streaks, XP, and awards without stress  
- Social layer — add friends, share progress, climb the leaderboard  
- Designed by a student, for students  

For the full overview, see [Overview.pdf](./Overview.pdf).  

---

## 📂 Press Assets  
- **Overview**: One-pager with key info  
- **Press Release**: Ready-to-use launch text (updated continously)
- **Screenshots**: High-res, unframed  
- **Icons & Logos**: App icon and wordmark (PNG, transparent background)  
- **Marketing Assets**: Lifestyle images and character art  

---

## 📰 Press Contact  
For press inquiries, interviews, or additional assets:  

**Florian Schweizer**  
📧 [flo@studywithnoko.com](mailto:flo@studywithnoko.com)  

---

## 🌐 Links  
- Website: [studywithnoko.com](https://studywithnoko.com)
- Indie dev portfolio: [flowritesco.de](https://flowritesco.de)  
- X (Twitter): [@flowritescode](https://twitter.com/flowritescode)  

---

Thanks for your interest in Noko!  